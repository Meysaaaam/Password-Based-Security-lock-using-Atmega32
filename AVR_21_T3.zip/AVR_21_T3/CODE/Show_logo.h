void Show_logo_wrong(void){
uint8_t n=0;
for(n=0;n<3;n++)
   {
   T;
   lcd_gotoxy(0,1);
   lcd_putsf("   <<Wrong>>   ");
   T;
   lcd_gotoxy(0,1);
   lcd_putsf("  << Wrong >>  ");
   T;
   lcd_gotoxy(0,1);
   lcd_putsf(" <<  Wrong  >> ");
   }
   T;
   lcd_clear();
 }
 
void Show_logo_correct(void){
uint8_t n=0;
for(n=0;n<3;n++)
   {
   T;
   lcd_gotoxy(0,1);
   lcd_putsf("  <<Correct>>  ");
   T;
   lcd_gotoxy(0,1);
   lcd_putsf(" << Correct >> ");
   T;
   lcd_gotoxy(0,1);
   lcd_putsf("<<  Correct  >>");
   }
   T;
   lcd_clear();
   
 }
 