#include <mega32.h>
#include <alcd.h>
#include <stdio.h>
#include <delay.h>
#include "define.h"
#include "mcu_init.h"
#include "Show_logo.h"


uint8_t number,count=0;
uint8_t n=9;
int8_t  str_num[4];
  


interrupt [EXT_INT0] void ext_int0_isr(void)
{
    if(status.flag_bit)
    {
        switch(DATA){
            case 0:
                number=1;
            break;
            case 1:
                number=2;
            break; 
            case 2:
                number=3;
            break;
            case 3:
                number='A';
            break;
            case 4:
                number=4;
            break;
            case 5:
                number=5;
            break;
            case 6:
                number=6;
            break;
            case 7:
                number='B';
            break;
            case 8:
                number=7;
            break;
            case 9:
                number=8;
            break;
            case 10:
                number=9;
            break;
            case 11:
                number='C';
            break;
            case 12:
                number='*';
            break;
            case 13:
                number=0;
            break;
            case 14:
                number='#';
            break;
            case 15:
                number='D';
            break;
        }
        str_num[count]=number;
        lcd_gotoxy(0,n);
        lcd_putchar('*');
        count++;
        n++;
    }
}



void main(void)
{

    mcu_init();
    lcd_clear();
    lcd_gotoxy(0,0);
    lcd_putsf("Password:");
    status.flag_bit=1;



    while (1)
      {

        if(count==4)
        {
            status.flag_bit=0;
            count=0;
            n=9;
            if(str_num[0]== 1 && str_num[1]== 4 && str_num[2]== 0 && str_num[3]== 3)
            {
                    
                    Relay_1=ON;
                    Show_logo_correct();
                    T1;
                    Relay_1=OFF;
                    status.flag_bit=0;
                    if(status.flag_bit==0)
                    { 
                        lcd_gotoxy(0,0);
                        lcd_putsf("Password:");
                        status.flag_bit=1;
                     }      
            } 
            else
            {
                    
                    BUZZ=ON;
                    Show_logo_wrong();
                    T1;
                    BUZZ=OFF;
                    status.flag_bit=0;
                    if(status.flag_bit==0)
                    { 
                        lcd_gotoxy(0,0);
                        lcd_putsf("Password:");
                        status.flag_bit=1;
                     }
                   

            }     
            
        }

      }

}
