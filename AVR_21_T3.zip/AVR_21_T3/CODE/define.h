#ifndef _DEFINE_H
#define _DEFINE_H

#include <mega32.h>
#include <alcd.h>
#include <stdio.h>

#define Relay_1    PORTC.0     // Relay_1
#define BUZZ       PORTC.1     // Relay_2
#define DATA       (PINA & 0x0f)


#define ON         1
#define OFF        0
#define T          delay_ms(200)
#define T1         delay_ms(400)



typedef    char           int8_t;
typedef    unsigned char  uint8_t;
typedef    int            int16_t;
typedef    unsigned int   uint16_t;
typedef    float          int32_t;


struct bit_type{
    uint8_t flag_bit:1;
    uint8_t flag_bit_1:1;}status;




void mcu_init(void);
void Show_logo_wrong(void);
void Show_logo_correct(void);

#endif 